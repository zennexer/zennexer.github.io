<?php

$conn = mysqli_connect('mysql.shockbyte.gra1.shockbyte.host', '9940f51611-db-admin', '2225f6ed65d2607c', '9940f51611-db')

?>